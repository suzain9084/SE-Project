python_dir = "E:\\Github_Repo\\SEC-Project\\backend\\venv\\Scripts\\python.exe"
connection_string = 'mysql+pymysql://root:Suzain%401234@localhost/grievance_management_system_db'